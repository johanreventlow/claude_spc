# testthat.R
# Test runner for SPC App

library(testthat)
library(shinytest2)

# Test directory
test_check("claude_spc")