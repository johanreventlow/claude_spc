# golem_utils.R
# Golem-inspired utility functions for robust Shiny app management
# Fase 3.4: Proper golem patterns implementation with YAML configuration support

#' Set Application Options (Golem-style)
#'
#' @description
#' Centralized options management following golem patterns. Allows runtime
#' configuration of app behavior without modifying global state directly.
#'
#' @param options List of options to set
#' @return Invisibly returns the updated options
#' @export
#'
#' @examples
#' \dontrun{
#' # Set development options
#' set_app_options(list(
#'   test_mode = TRUE,
#'   debug_level = "DEBUG",
#'   auto_load_data = TRUE
#' ))
#'
#' # Set production options
#' set_app_options(list(
#'   production_mode = TRUE,
#'   debug_level = "ERROR",
#'   auto_restore = TRUE
#' ))
#' }
set_app_options <- function(options = list()) {
  if (length(options) == 0) {
    return(invisible(NULL))
  }

  log_debug(paste("Setting app options:", length(options), "options provided"), "GOLEM_OPTIONS")

  # Default app options
  default_options <- list(
    production_mode = FALSE,
    test_mode = FALSE,
    debug_level = "INFO",
    auto_load_data = NULL,
    auto_restore = NULL,
    browser_launch = NULL,
    port = NULL
  )

  # Merge with provided options
  merged_options <- utils::modifyList(default_options, options)

  # Set options using R's standard options mechanism
  for (option_name in names(merged_options)) {
    option_key <- paste0("claudespc.", option_name)
    option_list <- list()
    option_list[[option_key]] <- merged_options[[option_name]]
    do.call("options", option_list)
  }

  log_debug(paste("✅ App options set successfully:", paste(names(merged_options), collapse = ", ")), "GOLEM_OPTIONS")
  return(invisible(merged_options))
}

#' Get Application Option (Golem-style)
#'
#' @description
#' Retrieve application options with fallback to defaults.
#'
#' @param option_name Name of the option to retrieve
#' @param default Default value if option is not set
#' @return Option value or default
#' @export
#'
#' @examples
#' \dontrun{
#' # Get with default
#' debug_level <- get_app_option("debug_level", "INFO")
#'
#' # Check if in test mode
#' is_test_mode <- get_app_option("test_mode", FALSE)
#' }
get_app_option <- function(option_name, default = NULL) {
  option_key <- paste0("claudespc.", option_name)
  return(getOption(option_key, default))
}

#' Check if Application is in Development Mode
#'
#' @description
#' Golem-style development mode detection combining explicit options
#' with environment detection.
#'
#' @return Boolean indicating development mode
#' @export
is_dev_mode <- function() {
  # Check explicit option first
  explicit_dev <- get_app_option("production_mode", NULL)
  if (!is.null(explicit_dev)) {
    return(!explicit_dev)  # dev mode is opposite of production mode
  }

  # Fall back to environment detection
  if (exists("detect_development_environment", mode = "function")) {
    return(detect_development_environment())
  }

  # Ultimate fallback
  return(interactive())
}

#' Check if Application is in Production Mode
#'
#' @description
#' Golem-style production mode detection.
#'
#' @return Boolean indicating production mode
#' @export
is_prod_mode <- function() {
  # Check explicit option first
  explicit_prod <- get_app_option("production_mode", NULL)
  if (!is.null(explicit_prod)) {
    return(explicit_prod)
  }

  # Fall back to environment detection
  if (exists("detect_production_environment", mode = "function")) {
    return(detect_production_environment())
  }

  # Ultimate fallback - if not interactive, assume production
  return(!interactive())
}

#' Development Application Runner (Golem-style)
#'
#' @description
#' Enhanced development runner med debugging og development-specific settings.
#' Equivalent til golem::run_dev() men tilpasset vores arkitektur.
#'
#' @param port Development port (default: 4040)
#' @param host Host address (default: 127.0.0.1 for development)
#' @param reload Enable hot reload (currently not implemented)
#' @param debug_level Debug level for development
#' @param ... Additional arguments passed to run_app()
#' @return Shiny app object
#' @export
#'
#' @examples
#' \dontrun{
#' # Basic development run
#' run_dev()
#'
#' # Development with specific settings
#' run_dev(port = 5050, debug_level = "DEBUG")
#' }
run_dev <- function(port = 4040,
                    host = "127.0.0.1",
                    reload = FALSE,
                    debug_level = "DEBUG",
                    ...) {

  log_debug("Starting development mode application", "DEV_MODE")

  # Set development-specific options
  dev_options <- list(
    production_mode = FALSE,
    test_mode = TRUE,
    debug_level = debug_level,
    auto_load_data = TRUE,
    auto_restore = FALSE,
    browser_launch = "rstudio_viewer"
  )

  log_debug(paste("Development options:", paste(names(dev_options), collapse = ", ")), "DEV_MODE")

  # Set environment for enhanced debugging
  Sys.setenv(SHINY_DEBUG_MODE = "TRUE")
  Sys.setenv(SPC_LOG_LEVEL = debug_level)

  if (reload) {
    warning("Hot reload is not yet implemented in run_dev()")
  }

  # Run app with development settings
  app_result <- run_app(
    port = port,
    launch_browser = NULL,  # Will use environment-aware detection
    options = dev_options,
    ...
  )

  log_debug("✅ Development application started successfully", "DEV_MODE")
  return(app_result)
}

#' Production Application Runner (Golem-style)
#'
#' @description
#' Production-ready app runner med optimerede settings for deployment.
#'
#' @param port Production port (default: NULL for system assignment)
#' @param host Host address (default: 0.0.0.0 for production)
#' @param ... Additional arguments passed to run_app()
#' @return Shiny app object
#' @export
run_prod <- function(port = NULL,
                     host = "0.0.0.0",
                     ...) {

  log_debug("Starting production mode application", "PROD_MODE")

  # Set production-specific options
  prod_options <- list(
    production_mode = TRUE,
    test_mode = FALSE,
    debug_level = "ERROR",
    auto_load_data = FALSE,
    auto_restore = TRUE,
    browser_launch = TRUE
  )

  log_debug(paste("Production options:", paste(names(prod_options), collapse = ", ")), "PROD_MODE")

  # Set environment for production
  Sys.setenv(SHINY_DEBUG_MODE = "FALSE")
  Sys.setenv(SPC_LOG_LEVEL = "ERROR")

  # Run app with production settings
  app_result <- run_app(
    port = port,
    launch_browser = TRUE,  # Always launch browser in production
    options = prod_options,
    ...
  )

  log_debug("✅ Production application started successfully", "PROD_MODE")
  return(app_result)
}

#' Get Application Information (Golem-style)
#'
#' @description
#' Retrieve information about the current application configuration.
#'
#' @return List with application information
#' @export
get_app_info <- function() {
  # Try to get version from DESCRIPTION file or default
  version <- tryCatch({
    if (file.exists("DESCRIPTION")) {
      desc <- read.dcf("DESCRIPTION")
      desc[1, "Version"]
    } else {
      "0.1.0"  # Default version
    }
  }, error = function(e) {
    "0.1.0"  # Fallback version
  })

  info <- list(
    package_name = "claudespc",
    version = version,
    mode = if (is_prod_mode()) "production" else "development",
    options = list()
  )

  # Get all claudespc options
  all_options <- options()
  claudespc_options <- all_options[grepl("^claudespc\\.", names(all_options))]
  names(claudespc_options) <- gsub("^claudespc\\.", "", names(claudespc_options))
  info$options <- claudespc_options

  return(info)
}

#' Application Resource Path Setup (Golem-style)
#'
#' @description
#' Setup static resource paths following golem conventions.
#'
#' @param path Path to add as resource
#' @param prefix Prefix for the resource path
#' @return Invisibly returns TRUE if successful
add_resource_path <- function(path = "www", prefix = "www") {
  # Use system.file() for packaged apps, fallback for development
  if (path == "www") {
    www_path <- system.file("app", "www", package = "claudespc")
    if (www_path == "") {
      www_path <- file.path("inst", "app", "www")
    }
    path <- www_path
  }

  if (dir.exists(path)) {
    shiny::addResourcePath(prefix, path)
    log_debug(paste("✅ Added resource path:", prefix, "->", path), "RESOURCE_PATHS")
    return(invisible(TRUE))
  } else {
    log_debug(paste("Resource path not found:", path), "RESOURCE_PATHS")
    return(invisible(FALSE))
  }
}

#' Favicon Setup (Golem-style)
#'
#' @description
#' Setup application favicon following golem patterns.
#'
#' @param path Path to favicon file
#' @return HTML tags for favicon
favicon <- function(path = "www/favicon.ico") {
  # For packaged apps, adjust favicon path
  if (path == "www/favicon.ico") {
    favicon_path <- system.file("app", "www", "favicon.ico", package = "claudespc")
    if (favicon_path == "") {
      favicon_path <- file.path("inst", "app", "www", "favicon.ico")
    }
    if (file.exists(favicon_path)) {
      path <- "www/favicon.ico"  # Keep relative path for href
    }
  }

  if (file.exists(path) || grepl("^www/", path)) {
    return(shiny::tags$head(shiny::tags$link(rel = "icon", href = path)))
  } else {
    log_debug(paste("Favicon not found:", path), "FAVICON")
    return(NULL)
  }
}

# YAML CONFIGURATION SUPPORT =================================================

#' Load Golem Configuration from YAML
#'
#' @description
#' Load application configuration fra inst/golem-config.yml following
#' standard golem patterns. Provides objektiv sammenligning med golem best practices.
#'
#' @param env Environment name (development, production, testing, default)
#' @param config_path Path to golem-config.yml file
#' @return List with configuration for specified environment
#' @export
#'
#' @examples
#' \dontrun{
#' # Load development configuration
#' dev_config <- get_golem_config("development")
#'
#' # Load production configuration
#' prod_config <- get_golem_config("production")
#'
#' # Load from custom path
#' config <- get_golem_config("development", "custom/path/config.yml")
#' }
get_golem_config <- function(env = NULL, config_path = "inst/golem-config.yml") {
  log_debug(paste("Loading golem configuration for environment:", env %||% "auto-detect"), "GOLEM_CONFIG")

  # Auto-detect environment if not specified
  if (is.null(env)) {
    env <- detect_golem_environment()
  }

  # Check if config file exists
  if (!file.exists(config_path)) {
    log_debug(paste("Golem config file not found:", config_path), "GOLEM_CONFIG")
    return(get_fallback_golem_config(env))
  }

  # Load YAML configuration
  tryCatch({
    config_data <- yaml::read_yaml(config_path)

    # Get configuration for specific environment
    if (env %in% names(config_data)) {
      env_config <- config_data[[env]]
      log_debug(paste("✅ Golem configuration loaded for environment:", env), "GOLEM_CONFIG")
      return(env_config)
    } else {
      log_debug(paste("Environment", env, "not found in config, using default"), "GOLEM_CONFIG")
      return(config_data[["default"]] %||% get_fallback_golem_config(env))
    }
  }, error = function(e) {
    log_error(paste("Failed to load golem config:", e$message), "GOLEM_CONFIG")
    return(get_fallback_golem_config(env))
  })
}

#' Detect Golem Environment
#'
#' @description
#' Detect current deployment environment following golem conventions.
#'
#' @return String indicating environment (development, production, testing, default)
detect_golem_environment <- function() {
  # Check R_CONFIG_ACTIVE first (standard practice)
  r_config <- Sys.getenv("R_CONFIG_ACTIVE", "")
  if (r_config != "") {
    mapped_env <- switch(r_config,
      "development" = "development",
      "dev" = "development",
      "production" = "production",
      "prod" = "production",
      "testing" = "testing",
      "test" = "testing",
      "default"  # Fallback
    )
    log_debug(paste("Environment detected from R_CONFIG_ACTIVE:", mapped_env), "GOLEM_ENV")
    return(mapped_env)
  }

  # Check application mode
  if (exists("is_prod_mode", mode = "function") && is_prod_mode()) {
    return("production")
  }

  if (exists("is_dev_mode", mode = "function") && is_dev_mode()) {
    return("development")
  }

  # Check for testing environment
  if (any(c("testthat", "test") %in% search())) {
    return("testing")
  }

  # Interactive session implies development
  if (interactive()) {
    return("development")
  }

  # Default fallback
  log_debug("No specific environment detected, using default", "GOLEM_ENV")
  return("default")
}

#' Get Fallback Golem Configuration
#'
#' @description
#' Provide fallback configuration when YAML loading fails.
#'
#' @param env Environment name
#' @return List with basic configuration
get_fallback_golem_config <- function(env) {
  log_debug(paste("Using fallback golem configuration for:", env), "GOLEM_FALLBACK")

  # Basic fallback configuration
  base_config <- list(
    golem_name = "claudeSPC",
    golem_version = "1.0.0",
    app_prod = FALSE,

    environment = list(
      type = env,
      is_development = (env == "development"),
      is_production = (env == "production"),
      is_testing = (env == "testing")
    ),

    logging = list(
      level = "INFO",
      enable_debug_mode = (env %in% c("development", "testing"))
    ),

    testing = list(
      auto_load_test_data = (env == "development"),
      test_data_file = if (env == "development") "R/data/spc_exampledata.csv" else NULL
    ),

    session = list(
      auto_restore_session = (env == "production")
    )
  )

  return(base_config)
}

#' Apply Golem Configuration to Runtime
#'
#' @description
#' Apply loaded golem configuration til application runtime.
#' Bridges between YAML config og eksisterende systems.
#'
#' @param golem_config Configuration from get_golem_config()
#' @return Invisible TRUE
#' @export
apply_golem_config <- function(golem_config) {
  log_debug("Applying golem configuration to runtime", "GOLEM_APPLY")

  if (is.null(golem_config)) {
    log_debug("No golem configuration to apply", "GOLEM_APPLY")
    return(invisible(FALSE))
  }

  # Apply app options
  if (!is.null(golem_config$environment)) {
    app_options <- list(
      production_mode = golem_config$environment$is_production %||% FALSE,
      test_mode = golem_config$testing$auto_load_test_data %||% FALSE,
      debug_level = golem_config$logging$level %||% "INFO"
    )
    set_app_options(app_options)
  }

  # Apply environment variables
  if (!is.null(golem_config$logging)) {
    if (!is.null(golem_config$logging$level)) {
      Sys.setenv(SPC_LOG_LEVEL = golem_config$logging$level)
    }

    if (!is.null(golem_config$logging$enable_debug_mode)) {
      Sys.setenv(SHINY_DEBUG_MODE = if (golem_config$logging$enable_debug_mode) "TRUE" else "FALSE")
    }
  }

  # Apply global variables for backward compatibility
  if (!is.null(golem_config$testing$auto_load_test_data)) {
    assign("TEST_MODE_AUTO_LOAD", golem_config$testing$auto_load_test_data, envir = .GlobalEnv)
  }

  if (!is.null(golem_config$session$auto_restore_session)) {
    assign("AUTO_RESTORE_ENABLED", golem_config$session$auto_restore_session, envir = .GlobalEnv)
  }

  log_debug("✅ Golem configuration applied to runtime", "GOLEM_APPLY")
  return(invisible(TRUE))
}

#' Get Current Golem Configuration Summary
#'
#' @description
#' Get human-readable summary af current golem configuration.
#'
#' @return Character vector with configuration summary
#' @export
get_golem_config_summary <- function() {
  env <- detect_golem_environment()
  config <- get_golem_config(env)

  if (is.null(config)) {
    return("Golem configuration not available")
  }

  summary_lines <- c(
    paste("Golem App:", config$golem_name %||% "claudeSPC"),
    paste("Version:", config$golem_version %||% "1.0.0"),
    paste("Environment:", config$environment$type %||% env),
    paste("Production Mode:", config$app_prod %||% FALSE),
    paste("Debug Mode:", config$logging$enable_debug_mode %||% FALSE),
    paste("Log Level:", config$logging$level %||% "INFO"),
    paste("Auto Load Test Data:", config$testing$auto_load_test_data %||% FALSE),
    paste("Auto Restore Session:", config$session$auto_restore_session %||% FALSE)
  )

  return(summary_lines)
}

# HELPER FUNCTIONS ============================================================

#' Null-coalescing operator
#'
#' @description
#' Return right-hand side if left-hand side is NULL
#'
#' @param x Left-hand side value
#' @param y Right-hand side value (fallback)
#' @return x if not NULL, otherwise y
`%||%` <- function(x, y) {
  if (is.null(x)) y else x
}