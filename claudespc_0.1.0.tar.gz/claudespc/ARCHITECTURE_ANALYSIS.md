# Arkitektur Analyse: Nuværende global.R Struktur

## Overordnet Status
**Dato:** 2025-09-21
**Fase:** 3.1 - Analyse af global.R struktur
**Formål:** Dokumenter all dependencies og design modulær refaktorering

---

## Nuværende global.R Arkitektur

### Dependency Loading Lag (Hierarkisk struktur)

#### 1. Core Dependencies
```r
# 13 library() kald som kræver global scope access
library(shiny)              # Core framework
library(bslib)              # UI framework
library(excelR)             # Excel-like tables
library(dplyr)              # Data manipulation
library(stringi)            # String operations
library(readr)              # CSV reading
library(readxl)             # Excel reading
library(shinycssloaders)    # Loading spinners
library(shinyWidgets)       # UI widgets
library(zoo)                # Rolling averages
library(scales)             # Plot formatting
library(lubridate)          # Date handling
library(openxlsx)           # Excel export
library(shinylogs)          # Logging

# 6 namespace-converted packages
# qicharts2::, ggplot2::, ggrepel::, shinyjs::, yaml::, later::
```

#### 2. Utilities Layer
```r
source_from_base("R/utils/logging.R")                   # ✅ Core logging system
source_from_base("R/utils/dependency_injection.R")     # ✅ DI framework
source_from_base("R/utils/shinylogs_config.R")         # ✅ Web logging config
source_from_base("R/utils/advanced_debug.R")           # ✅ Debug infrastructure
source_from_base("R/utils/end_to_end_debug.R")         # ✅ E2E debug tools
```

#### 3. Configuration Layer
```r
source_from_base("R/config/hospital_branding.R")       # ✅ Hospital themes
source_from_base("R/config/chart_types.R")             # ✅ SPC chart configs
source_from_base("R/config/observer_priorities.R")     # ✅ Reactive priorities
source_from_base("R/config/state_management.R")        # ✅ Central state setup
source_from_base("R/config/ui_config.R")               # ✅ UI constants
source_from_base("R/config/spc_config.R")              # ✅ SPC parameters
source_from_base("R/config/system_config.R")           # ✅ System settings
```

#### 4. Core Functions Layer
```r
source_from_base("R/core/spc_helpers.R")               # ✅ SPC calculations
source_from_base("R/fct_spc_plot_generation.R")        # ✅ Plot generation
source_from_base("R/core/file_io.R")                   # ✅ File operations
source_from_base("R/core/autodetect_helpers.R")        # ✅ Column detection
source_from_base("R/utils/local_storage.R")            # ✅ Local storage mgmt
```

#### 5. Server Components Layer
```r
source_from_base("R/server/utils_session_helpers.R")   # ✅ Session utilities
source_from_base("R/server/utils_server_management.R") # ✅ Server management (DUPLICATE)
source_from_base("R/server/utils_column_management.R") # ✅ Column handling
source_from_base("R/fct_file_operations.R")            # ✅ File upload logic
source_from_base("R/fct_visualization_server.R")       # ✅ Viz server
source_from_base("R/modules/mod_spc_chart_server.R")   # ✅ Chart module server
```

#### 6. Performance Optimizations Layer
```r
source_from_base("R/server/performance_helpers.R")     # ✅ Perf utilities
source_from_base("R/server/performance_optimizations.R") # ✅ Perf optimizations
source_from_base("R/server/plot_optimizations.R")      # ✅ Plot performance
```

#### 7. UI Components Layer
```r
source_from_base("R/modules/mod_spc_chart_ui.R")       # ✅ Chart module UI
```

#### 8. Main App Components Layer
```r
source_from_base("R/server/app_server.R")              # ✅ Main server function
source_from_base("R/ui/app_ui.R")                      # ✅ Main UI function
source_from_base("R/run_app.R")                        # ✅ App launcher
```

#### 9. Additional Utilities Layer (Late loading)
```r
source_from_base("R/utils/danish_locale.R")            # ✅ Danish formatting
source_from_base("R/ui/utils_ui_helpers.R")            # ✅ UI helper functions
source_from_base("R/ui/utils_ui_components.R")         # ✅ UI components
source_from_base("R/ui/utils_ui_updates.R")            # ✅ UI update utilities
source_from_base("R/server/utils_event_system.R")      # ✅ Event system
source_from_base("R/server/utils_server_management.R") # ❌ DUPLICATE loading
source_from_base("R/utils/performance.R")              # ✅ Performance tools
source_from_base("R/utils/memory_management.R")        # ✅ Memory management
```

#### 10. Specialized Functionality Layer
```r
source_from_base("R/fct_autodetect_unified.R")         # ✅ Auto-detection engine
```

---

## Arkitekturelle Problemer Identificeret

### 🔴 Kritiske Issues

1. **Duplicate Loading**
   - `R/server/utils_server_management.R` loaded TWICE (linje 94 og 230)
   - Kan forårsage function redefinition warnings

2. **Dependency Order Issues**
   - UI components loading efter main app components
   - Kan skabe missing function errors under visse omstændigheder

3. **Circular Dependencies Risk**
   - `app_server.R` og `app_ui.R` loaded før alle utilities
   - Utilities loaded efter kan ikke bruges i main components

### 🟡 Strukturelle Issues

4. **Mixed Loading Patterns**
   - Nogle utilities loaded tidligt, andre sent
   - Inkonsistent separation af concerns

5. **Global Function Pollution**
   - 35+ source files loaded i global environment
   - Alle funktioner bliver globally accessible
   - Namespace pollution og naming conflicts risk

6. **Configuration Spread**
   - Konfiguration både i `R/config/` og direkte i `global.R`
   - Eksempel: `TEST_MODE_AUTO_LOAD`, `AUTO_RESTORE_ENABLED` i `global.R`

### 🟢 Performance Issues

7. **Eager Loading**
   - Alle 35 filer loaded ved app start
   - Ingen lazy loading af sjældent brugte komponenter

8. **Memory Footprint**
   - Alle funktioner loaded i memory ved startup
   - Kunne optimeres med modular loading

---

## Dependency Graph Analysis

### Top-Level Dependencies (No internal deps)
- `R/utils/logging.R` - Foundation logging
- `R/config/*` - All configuration files
- `R/utils/dependency_injection.R` - DI framework

### Mid-Level Dependencies (Build on top-level)
- `R/core/*` - Core business logic functions
- `R/utils/advanced_debug.R` - Depends on logging
- `R/server/utils_session_helpers.R` - Depends on config

### High-Level Dependencies (Build on mid-level)
- `R/modules/*` - Shiny modules
- `R/server/app_server.R` - Main server
- `R/ui/app_ui.R` - Main UI
- `R/fct_*` - Feature functions

### Critical Dependencies (Must load last)
- `R/run_app.R` - Depends on app_server.R og app_ui.R

---

## Proposed Modular Architecture

### Fase 3.2: Design for R/app_initialization.R

```r
# Proposed structure for modular initialization
initialize_app <- function() {
  # 1. Load utilities foundation
  load_utils_foundation()

  # 2. Load configuration
  load_app_configuration()

  # 3. Load core functions
  load_core_functions()

  # 4. Load server components
  load_server_components()

  # 5. Load UI components
  load_ui_components()

  # 6. Initialize app components
  initialize_main_app()

  # 7. Setup performance optimizations
  setup_performance_optimizations()
}
```

### Fase 3.2: Design for R/app_dependencies.R

```r
# Centralized dependency management
manage_app_dependencies <- function() {
  # Core framework dependencies (always required)
  ensure_core_packages()

  # Feature dependencies (conditional loading)
  ensure_feature_packages()

  # Development dependencies (only in dev mode)
  ensure_dev_packages()
}
```

### Fase 3.2: Design for R/app_config.R

```r
# Centralized configuration management
initialize_app_config <- function() {
  # Environment detection
  setup_environment()

  # Feature flags
  setup_feature_flags()

  # Performance settings
  setup_performance_config()

  # Logging configuration
  setup_logging_config()
}
```

---

## Risk Assessment for Refaktorering

### 🔴 Høj Risiko
- **Loading order changes** - Kan bryde function dependencies
- **Global environment changes** - Functions might ikke være tilgængelige
- **Configuration timing** - Config skal være tilgængelig når needed

### 🟡 Medium Risiko
- **Performance regressions** - Modular loading kan påvirke startup time
- **Memory usage changes** - Different loading pattern kan ændre memory profile

### 🟢 Lav Risiko
- **Code organization** - Purely structural changes
- **Documentation updates** - No runtime impact

---

## Testing Strategy for Fase 3

### Pre-refactoring Tests
1. **Function Inventory Test**
   ```r
   # Record all currently available functions
   pre_refactor_functions <- ls(.GlobalEnv)
   ```

2. **Dependency Load Test**
   ```r
   # Verify current loading succeeds
   source("global.R")  # Should complete without errors
   ```

### Post-refactoring Tests
1. **Function Availability Test**
   ```r
   # Verify all functions still available after refactoring
   post_refactor_functions <- ls(.GlobalEnv)
   missing_functions <- setdiff(pre_refactor_functions, post_refactor_functions)
   ```

2. **App Startup Test**
   ```r
   # Verify app can still start
   app <- shinyApp(ui = app_ui(), server = app_server)
   ```

3. **Feature Integration Test**
   ```r
   # Test key user workflows still work
   # File upload, column detection, plot generation
   ```

---

## Næste Skridt: Implementation Plan

### Fase 3.2: Opret Modulære Komponenter
1. **R/app_config.R** - Centraliseret konfiguration
2. **R/app_dependencies.R** - Dependency management
3. **R/app_initialization.R** - Modular initialization logic

### Fase 3.3: Refaktorér run_app()
1. Fix `.rs.invokeShinyWindowViewer` environment-awareness
2. Implement graceful fallback patterns
3. Test browser launch i alle miljøer

### Fase 3.4: Implement Golem Patterns
1. Use `golem::with_golem_options()` for configuration
2. Implement `golem::run_dev()` for development
3. Structure app som ægte R package

---

## Definition of Done for Fase 3

- [ ] Architecture documented i this file
- [ ] Duplicate loading issue resolved
- [ ] Dependency order optimized
- [ ] Modular initialization components created
- [ ] run_app() environment-awareness implemented
- [ ] All tests pass with new architecture
- [ ] App startup time remains acceptable
- [ ] Memory footprint ikke significantly increased
- [ ] Golem patterns implemented where applicable

**Estimat:** 4-6 timer for komplet Fase 3 implementation